import React from 'react';  // var prom = require('imeNaBiblioteka');


export default class App extends React.Component {

  render(){

    return(
      <div id="app">
          <h2>Hello World</h2>
      </div>
    )
  
  }

}