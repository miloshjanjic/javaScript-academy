import React from 'react';

export function Hello() {

    return(
        <div id="hello">
            <h1>Hello User</h1>
        </div>
    )
}