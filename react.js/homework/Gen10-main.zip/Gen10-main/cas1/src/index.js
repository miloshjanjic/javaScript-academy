import React from 'react';
import ReactDOM from 'react-dom';
// import App from './App';
import AppFunc from './AppFunc';

ReactDOM.render(<AppFunc />,document.getElementById('root'));