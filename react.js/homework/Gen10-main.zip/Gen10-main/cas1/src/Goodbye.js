import React from 'react';

export function Goodbye() {

    return(
        <div id="goodbye">
            <p>Goodbye</p>
        </div>
    )
}