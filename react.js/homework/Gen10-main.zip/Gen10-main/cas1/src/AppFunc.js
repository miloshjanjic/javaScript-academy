import React from 'react';
import {Hello} from './Hello';
import {Goodbye} from './Goodbye';

export default function AppFunc() {

    return(
        <div id="app-func">
                <Goodbye />
            <h2>Functional Components</h2>
                <Hello />
            <h2>Functional Components</h2>
                <Hello />
            <p id="calculate">
                The result from 5+3 = {5+3}
            </p>
        </div>
    )

}