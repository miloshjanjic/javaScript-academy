import React from 'react';

export function Info() {
    return <h2>Info</h2>
}