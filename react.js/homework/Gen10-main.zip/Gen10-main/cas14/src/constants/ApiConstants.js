export const api = {
    base:'https://api.openweathermap.org/data/2.5',
    key:'1130df850abd918970e338266bf4791d'
}