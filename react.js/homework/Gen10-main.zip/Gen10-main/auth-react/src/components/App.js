import React, { useEffect, useState } from 'react';
import { Router, Route, Link } from 'react-router-dom';

import { history } from '../_helpers';
import { authenticationService } from '../_services';
import { PrivateRoute } from './PrivateRoute';
import { HomePage } from './HomePage';
import { LoginPage } from './LoginPage';

function App() {

    const [currentUser, setCurrentUser] = useState(null)

    useEffect(() => {
        authenticationService.currentUser.subscribe(x => setCurrentUser(x));

    }, [])

    function logout() {
        authenticationService.logout();
        history.push('/login');
    }

    return (
        <Router history={history}>
            <div>
                {currentUser &&
                    <>
                        <button onClick={logout} >Logout </button>
                    </>
                }
                <>
                    <PrivateRoute exact path="/" component={HomePage} />
                    <Route path="/login" component={LoginPage} />
                </>
            </div>
        </Router>
    );

}

export { App }; 