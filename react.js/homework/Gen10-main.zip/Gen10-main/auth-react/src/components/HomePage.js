import React, { useEffect, useState } from 'react';

import { userService, authenticationService } from '../_services';

function HomePage() {

    const [users,setUsers] = useState(null)
    const [currentUser,setCurrentUser] = useState(authenticationService.currentUserValue)
    useEffect(()=>{
        userService.getAll().then(appusers => setUsers(appusers));
    },[])

        return (
            <div>
                <h1>Hi {currentUser.firstName}!</h1>
                <p>You're logged in with React & JWT!!</p>
                <h3>Users from secure api end point:</h3>
                {users &&
                    <ul>
                        {users.map(user =>
                            <li key={user.id}>{user.firstName} {user.lastName}</li>
                        )}
                    </ul>
                }
            </div>
        );
    }


export { HomePage };