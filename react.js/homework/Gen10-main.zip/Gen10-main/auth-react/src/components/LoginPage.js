import React, { useEffect, useState } from 'react';

import { authenticationService } from '../_services';

function LoginPage(props) {



    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    useEffect(() => {
        // redirect to home if already logged in
        if (authenticationService.currentUserValue) {
            props.history.push('/');
        }
    }, [props])

    return (
        <div>
            <div className="alert alert-info">
                Username: test<br />
                    Password: test
                </div>
            <h2>Login</h2>
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} />
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} />

            <button type="submit" onClick={() => {
                authenticationService.login(username, password)
                    .then(
                        user => {
                            const { from } = props.location.state || { from: { pathname: "/" } };
                            props.history.push(from);
                        },
                        error => {
                            alert(error)
                        }
                    );
            }} >Login</button>

        </div>
    )
}


export { LoginPage }; 