import {combineReducers} from 'redux';
import {usersReducer} from './components/users/duck';

export default combineReducers({
    usersReducer
})