import React from 'react'

export function UserEdit(props) {
    return (
        <div>
            <input value={props.user.name} onChange={props.setUser} type="text" />
            <input value={props.user.username} onChange={props.setUser} type="text" />
            <input value={props.user.email} onChange={props.setUser} type="text" />
        </div>
    )
}
