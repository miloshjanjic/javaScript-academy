export const properties = {
    api:{
        root: 'https://jsonplaceholder.typicode.com'
    }
} 