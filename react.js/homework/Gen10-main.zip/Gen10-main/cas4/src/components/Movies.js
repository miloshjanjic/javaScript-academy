import React from 'react';
import PropTypes from 'prop-types';

export function Movies(props){

    console.log(props)
    return(
        <div id="movies">
            { props.filmovi.map((film,i)=>{
                return(
                    <div key={i}>
                        <h1><span>Movie Title</span> {film.ime}</h1>
                        <p><span>Movie Genre</span> {film.zanr}</p>
                        <p><span>Release Date</span> {film.godina}</p>
                        <a href={film.link}>Go to Imdb Page </a>
                        <br/>
                        <img width="150" height={"200"} src={film.slika} alt={film.ime} /> 
                    </div>
                )
            })
            }
        </div>
    )

}

Movies.propTypes = {
    filmovi: PropTypes.array.isRequired
}