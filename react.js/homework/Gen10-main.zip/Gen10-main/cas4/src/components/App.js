import React,{useState,useEffect} from 'react';
// import {Movies} from './Movies';

// var movies=[
//   {ime:'Back to the Future',zanr:'Sci-Fi',godina:1985,link:'https://www.imdb.com/title/tt0088763/?ref_=nv_sr_srsg_0',slika:'https://m.media-amazon.com/images/M/MV5BZmU0M2Y1OGUtZjIxNi00ZjBkLTg1MjgtOWIyNThiZWIwYjRiXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_UY1200_CR71,0,630,1200_AL_.jpg'},
//   {ime:'Pulp Fiction',zanr:'Crime',godina:1994,link:'https://www.imdb.com/title/tt0110912/?ref_=nv_sr_srsg_0',slika:'https://upload.wikimedia.org/wikipedia/en/3/3b/Pulp_Fiction_%281994%29_poster.jpg'},
//   {ime:'The Dark Knight',zanr:'Action',godina:2008,link:'https://www.imdb.com/title/tt0468569/?ref_=nv_sr_srsg_0',slika:'https://upload.wikimedia.org/wikipedia/en/8/8a/Dark_Knight.jpg'}
// ];

export function App(){

  const [username,setUsername] = useState('');
  const [password,setPassword] = useState('');
  const [count,setCount] = useState(0);

  useEffect(()=>{
    console.log("Username: ",username)
    console.log("Password: ",password)
  },[username,password])


  function prikaziVrednosti(){
    alert(`Username: ${username}\nPassword: ${password}\nCounter: ${count}`)
  }

  return(
    <div id="app">
        <h2>App</h2>
        <input 
          type="text"
          placeholder="Username"
          value={username}
          onChange={(event)=>{setUsername(event.target.value)}}
        />
        <br/>
        <br/>
        <input 
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e)=>{setPassword(e.target.value)}}
        />
        <br/>
        <br/>
                <button onClick={prikaziVrednosti}>
            Show Values
        </button>
        <br/>
        <br/>
        <h2>Counter: {count}</h2>

        <img width={450} height={600} 
          src={'https://m.media-amazon.com/images/M/MV5BZmU0M2Y1OGUtZjIxNi00ZjBkLTg1MjgtOWIyNThiZWIwYjRiXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_UY1200_CR71,0,630,1200_AL_.jpg'}
          alt="poster"
          onClick={()=>{setCount(count + 1)}}
        />


        {/* <Movies
          filmovi={movies}
        /> */}
    </div>
  )
}