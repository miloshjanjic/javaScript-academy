import React from 'react';
import ReactDOM from 'react-dom';
import {App} from './components/App';
import {SecondApp} from './components/SecondApp'

ReactDOM.render(
  <App/>,
  document.getElementById('root')
);
