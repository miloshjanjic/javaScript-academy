import React from 'react';

export class StudentClass extends React.Component{

    render(){
        return(
            <div id="student-class">
                <h2>Class Component {this.props.studentKM.ime} </h2>
            </div>
        )
    }
}