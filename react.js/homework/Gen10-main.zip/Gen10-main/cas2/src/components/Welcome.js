import React from 'react';

export function Welcome(props){

    return(
        <div id="welcome">
            <p>Welcome, {props.ime}
             {props.prezime} </p>
            <p>Age: {props.age} </p>
        </div>
    )
}