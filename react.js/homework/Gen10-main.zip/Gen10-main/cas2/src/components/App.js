import React from 'react';
import { Welcome } from './Welcome';
import { Comments } from './Comments';
import { Student } from './Student';
import { FruitList } from './FruitList';
import { StudentClass} from './StudentClass';

const name = "Filip";

var student = {
    ime: 'Filip',
    prezime: 'Dzukovski',
    brNaIndeks: 141088
}

let fruits = ["apple","orange","mango"];


export function App() {

    return (
        <div id="app">
            <h2>App</h2>
            <Welcome
                ime={name}
                prezime={"Dzukovski"}
                age={24}
            />
            <Welcome
                ime={"Pero"}
                prezime={"Perovski"}
                age={12}
            />
            <Comments
                hasComments={true}
                multipleComments={true}
            />
            <Student studentKM={student} />
            <FruitList listOfFruits={fruits} />
            <StudentClass studentKM ={student} />
        </div>
    )
}