import React, { useState } from 'react';

export function Domasna() {

    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [mobile, setMobile] = useState('');
    const [DOB, setDOB] = useState('');
    const [gender, setGender] = useState('');
    const [showTable,setShowTable] = useState(false);


    function showValues(event){
        event.preventDefault();
        setShowTable(!showTable)
    }

    return (
        <div id="domasna">
            <h2>Yahoo Form</h2>
            <form onSubmit={showValues}>
                <input
                    type="text"
                    placeholder="Enter First Name"
                    value={firstName}
                    onChange={e => { setFirstName(e.target.value) }}
                />
                <br />
                <br />
                <input
                    type="text"
                    placeholder="Enter Last Name"
                    value={lastName}
                    onChange={e => { setLastName(e.target.value) }}
                />
                <br />
                <br />
                <input
                    type="email"
                    placeholder="Enter Email"
                    value={email}
                    onChange={e => { setEmail(e.target.value) }}
                />
                <br />
                <br />
                <input
                    type="password"
                    placeholder="Enter Password"
                    value={password}
                    onChange={e => { setPassword(e.target.value) }}
                />
                <br />
                <br />
                <input
                    type="tel"
                    placeholder="07x-xxx-xxx"
                    value={mobile}
                    pattern="[0-9]{3}-[0-9]{3}-[0-9]{3}"
                    onChange={e => { setMobile(e.target.value) }}
                />
                <br />
                <br />
                <input
                    type="date"
                    value={DOB}
                    onChange={e => { setDOB(e.target.value) }}
                />
                <br />
                <br />
                <input
                    type="text"
                    placeholder="Enter Gender"
                    value={gender}
                    onChange={e => { setGender(e.target.value) }}
                />
                <br />
                <br />
                <button type="submit">
                    {showTable ? "Hide Values" : 'Show Values'}
                </button>

            </form>
            <br />
            <br />
            { showTable && <table border="1">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Tel.</th>
                        <th>DOB</th>
                        <th>Gender</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{firstName}</td>
                        <td>{lastName}</td>
                        <td>{email}</td>
                        <td>{password}</td>
                        <td>{mobile}</td>
                        <td>{DOB}</td>
                        <td>{gender}</td>
                    </tr>
                </tbody>
            </table>}

        </div>
    )
}