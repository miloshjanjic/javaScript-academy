import React from 'react';
// import ClassComponent from './ClassComponent';
import {FuncComponent} from './FuncComponent';

export function App() {

    return (
        <div id="app">
            <h2>Redux Intro</h2>
            {/* <ClassComponent/> */}
            <FuncComponent />
        </div>
    )
}