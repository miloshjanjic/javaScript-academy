import React,{useEffect} from 'react';
import {sayHello} from './../actions/SayHelloActions';
import {useDispatch,useSelector} from 'react-redux';

export function FuncComponent() {
    
    const greeting = useSelector(state=>state.SayHelloReducer.greeting);
    const dispatch = useDispatch();
    
    useEffect(()=>{
        dispatch(sayHello())
    },[dispatch])

    return (
        <div id="func-component">
            <h2>Functional Component</h2>
            <h2>{greeting}</h2>
        </div>
    )
}