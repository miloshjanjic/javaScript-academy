import {combineReducers} from 'redux';
import SayHelloReducer from './SayHelloReducer';

export default combineReducers({
    SayHelloReducer
})